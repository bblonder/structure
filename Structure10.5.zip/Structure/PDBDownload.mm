#include <zlib.h>
#include <stdio.h>

#import "PDBDownload.h"
#include "FTP.h"
#include "RandomUtil.h"
#include "FileUtility.h"

@implementation PDBDownload

- (NSString*) getPDBName:(std::string)remoteName
{
	return [[[NSString stringWithCString:remoteName.substr(3,4).c_str() encoding:[NSString defaultCStringEncoding]] uppercaseString] retain];
}

- (void) downloadNewPDB
{
	std::string basePath = "ftp://ftp.wwpdb.org/pub/pdb/data/structures/divided/pdb/";
	std::vector<std::string> baseContents, subContents;
	
	if (printFTPDirectory(basePath, &baseContents))
	{	
		int numBaseContents = baseContents.size();
		if (numBaseContents >= 1)
		{
			std::string subPath = basePath + baseContents[randomInt(0, numBaseContents - 1)] + "/";
		
			if (printFTPDirectory(subPath, &subContents))
			{
				int numSubContents = subContents.size();
				if (numSubContents >= 1)
				{
					std::string fileName = subContents[randomInt(0, numSubContents - 1)];
					std::string finalPath = subPath + fileName;
					
					pdbID = [self getPDBName:fileName];
					
					tempPath = [NSString stringWithCString:tmpnam(NULL) encoding:[NSString defaultCStringEncoding]];
					
					NSURLRequest *request = [NSURLRequest 
						requestWithURL:[NSURL URLWithString:[NSString stringWithCString:finalPath.c_str() encoding:[NSString defaultCStringEncoding]]]
						cachePolicy:NSURLRequestUseProtocolCachePolicy
						timeoutInterval:30.0];
						
					NSURLDownload *download = [[NSURLDownload alloc] initWithRequest:request delegate:self];
					[download setDestination:tempPath allowOverwrite:YES];
					
					if (!download)
					{
						NSLog(@"something bad happened to the download");
					}
				}
				else
				{
					NSLog(@"problem with subcontents");
				}
			}
		}
		else
		{
			NSLog(@"problem with basecontents");
		}
	}
}

- (void)download:(NSURLDownload *)download didFailWithError:(NSError *)error
{
    // release the connection
    [download release];

    NSLog(@"Download failed! Error - %@ %@", [error localizedDescription], [[error userInfo] objectForKey:NSErrorFailingURLStringKey]);
}

- (void)downloadDidFinish:(NSURLDownload *)download
{
    [download release];
	
	NSString* localDir = [[NSBundle bundleForClass:NSClassFromString(@"StructureOpenGLView")] resourcePath];
	bool exists = [[NSFileManager defaultManager] fileExistsAtPath:localDir];
	if (!exists)
	{
		[[NSFileManager defaultManager] createDirectoryAtPath:localDir attributes:NULL];
		NSLog(@"had to create the resourcedirectory - bad!");
	}
	
	NSString *localPath = [[localDir stringByAppendingPathComponent:pdbID] stringByAppendingString:@".pdb"];
	
	[[NSFileManager defaultManager] movePath:tempPath toPath:localPath handler:NULL];
	
	
	
	NSArray *contents = [FileUtility filesWithExtension:@"PDB" withArray:[[NSFileManager defaultManager] directoryContentsAtPath:localDir]];
	if (contents != nil)
	{
		int numFilesToRemove = [contents count] - [[ScreenSaverDefaults defaultsForModuleWithName:@"Structure"] integerForKey:@"CacheSize"]; // cache size (fixed)
		for (int i=0; i<numFilesToRemove; i++)
		{
			int numContentsCount = [contents count];
			if (numContentsCount >= 1)
			{
				NSString *fullPath = [localDir stringByAppendingPathComponent:[contents objectAtIndex:randomInt(0, numContentsCount - 1)]];
				[[NSFileManager defaultManager] removeFileAtPath:fullPath handler:nil];
				NSLog(@"removing");
				NSLog(fullPath);
			}
			else
			{
				NSLog(@"numContentsCount bad");
			}
		}
	}
	else
	{
		NSLog(@"uh oh - directory didn't exist!");
	}
}
@end
