#ifndef _FTP_H_
#define _FTP_H_

#include <vector>
#include <string>

#include <CoreServices/CoreServices.h>
#include <CoreFoundation/CoreFoundation.h>
#include <SystemConfiguration/SystemConfiguration.h>

#include <sys/dirent.h>
#include <sys/stat.h>
#include <string.h>         // strmode
#include <stdlib.h>
#include <inttypes.h>
#include <stdio.h>

bool printFTPDirectory(std::string dir, std::vector<std::string>* contentsList);

#endif
