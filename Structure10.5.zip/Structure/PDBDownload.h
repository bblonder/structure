#include <string>

@interface PDBDownload : NSObject 
{
	NSString *tempPath, *pdbID;
}

- (void) downloadNewPDB;
- (NSString*) getPDBName:(std::string)remoteName;

@end
