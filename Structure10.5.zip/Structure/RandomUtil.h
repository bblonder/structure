#ifndef _RANDOM_UTIL_
#define _RANDOM_UTIL_

// both include upper bounds
float randomFloat(float lower, float upper);
int randomInt(int lower, int upper);

#endif